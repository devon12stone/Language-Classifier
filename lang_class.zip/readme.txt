Executing Code:

The model developed trains automatically when the Python file lang_class.py is run.
The Python file can be run from  the terminal.

Expected Output:
Overall Predicitve Accuracy
0.976

Enlgish Predicitve Accuracy
0.993

Afrikaans Predicitve Accuracy
0.992

Ductch Predicitve Accuracy
0.308